

Love
- 1.2 The Company (DONE)
- 1.4 Remove stored employees (DONE)
- 1.7 Retrieve expenses with total salary (DONE)
- 1.10 Show the number of employees per degree (DONE)
- 2.1 No employee found. (DONE)
- 2.4 Presenting the creation or assignment with invalid Manager data. (DONE)

Emma
- 1.3 Create different types of employees (DONE)
- 1.5 Retrieve string from an employee (DONE)
- 1.8 Retrieve employees sorted by gross salary. (DONE)
- 2.2 Specific employee not found or not registered yet.
- 2.5 Presenting the creation or assignment with invalid Directors data.

Martin
- 1.1 Create and store regular employees (DONE)
- 1.6 Retrieve a string including all employees (DONE)
- 1.9 Update Employee’s Information (DONE, but salary calculations NOT WORKING)
- 2.3 Preventing the creation or assignment with invalid Employee data. (DONE)
- 2.6 Preventing the creation or assignment with invalid Interns data. (DONE)

Together:
- 1.11 Promotion of employees
- Design Task (Factory Pattern)
- Change from e to employee.
